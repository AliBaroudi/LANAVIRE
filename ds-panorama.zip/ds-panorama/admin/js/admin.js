(function( $ ) {
  window.localStorage.clear()
})( jQuery );
