=== Panorama for Divi ===
Contributors: Divi Sensei
Tags: divi, divi builder, divi page builder, divi theme, extra theme, elegant themes, extra module, divi module, module, panorama, pano
Requires at least: 4.0
Tested up to: 4.8.1
Stable tag: 1.0

== Description ==
Display interactive panorama images

== Installation ==
In order to install the plugin, simply upload it as a zip archive in the WordPress Admin Plugin page or upload the unpacked archive to your WordPress plugin folder via FTP.

Then head over to the WordPress Admin Plugin page and activate the plugin.

== Changelog ==

= 1.0 =
* Initial release
